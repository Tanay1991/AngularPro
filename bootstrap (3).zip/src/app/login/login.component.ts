import { Component, OnInit,ElementRef ,ViewChild,Output,EventEmitter,Input} from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
@ViewChild('rt') rt: ElementRef;
@Input() errMessage:string;
width:any;
color:any;
enterPassword:string;

@Output() logincrd= new EventEmitter();
userName:string='';
password:string='';
  constructor() { }

  ngOnInit() {
    console.log('LoginComponent');
     //this.width='100';
  }
  onSubmit(event)
  {   
   
    this.logincrd.emit({'userName':this.userName,'password':this.password});
    

  }
  onKey(event)
  {
      //console.log(JSON.stringify(event.target.value));
      this.enterPassword=event.target.value;
      if(this.enterPassword.length>1)
      {
        this.width='25%';
        this.color='red';
      }
      if(this.enterPassword.length>3)
      {
        this.width='50%';
         this.color='yellow';
      }
      if(this.enterPassword.length>5)
      {
        this.width='100%';
        this.color='green';
      }
  }
  
 

}