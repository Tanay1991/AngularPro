import { Component,OnInit ,ElementRef,ViewChild} from '@angular/core';

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent  implements OnInit{

  loginFlag:boolean;
  welcomeFlag:boolean;
  globName:string;
  globPass:string;
  errMessage:string;
  welcomeBtn:boolean;
  logout:boolean=false;
  @ViewChild('rt') rt: ElementRef;

  ngOnInit()
  {
    this.loginFlag=false;
    this.welcomeFlag=false;
    this.welcomeBtn=true;
    this.globName='';
    this.globPass='';
    this.errMessage='';
    
  }

  login(login:string)
  {
      console.log('Button Click'+login);
      this.loginFlag=true;
      this.welcomeFlag=false;
       this.logout=false;
     
  }
  welcome(welcome:string)
  {
     console.log('Button Click'+welcome);
      this.logout=false;
      //this.welcomeFlag=true;
      this.loginFlag=false;
      if(this.globName == null || this.globPass == null)
      {
        this.welcomeFlag=false;
      }
  }
  getLoginCrd(event)
  {
      console.log(event.userName);
      this.globName=event.userName;
      this.globPass=event.password;
      if(event.userName!=='' && event.password!=='')
      {
        this.welcomeFlag=true;
        this.loginFlag=false;
        this.welcomeBtn=false;
      }
      else
      {
        this.welcomeFlag=false;
        this.loginFlag=true;
        this.welcomeBtn=true;
        this.errMessage='Invalid User Name OR Password!!!!';
      }

  }
logOut()
{
    this.logout=true;
    this.welcomeFlag=false;
    this.loginFlag=false;
      setTimeout(()=>{    
      this.logout = false;
 }, 3000);
}
  
}
